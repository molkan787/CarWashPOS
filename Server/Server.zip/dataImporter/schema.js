module.exports = {
    barcode: 'Card No.',
    balance: 'Balance',
}