module.exports = {
    newPrepaidCardItemId: 10001,
    reloadPrepaidCardItemId: 10002,
    giftCertificateItemId: 10003,

    newPrepaidCardItemName: 'New Prepaid Card',
    reloadPrepaidCardItemName: 'Prepaid Card Reload',
    giftCertificateItemName: 'Gift Certificate',

    productWithTaxesType: 1,
    productWithoutTaxesType: 3,
    
    washesCats: [1, 2, 6, 7],
};