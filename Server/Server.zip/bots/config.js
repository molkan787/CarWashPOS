module.exports = {
    email: {
        user: 'avantiautospa@gmail.com',
        password: 'brijen2755',
        sendTo: 'molkan787@outlook.com',
    }
}