//const statsNotifier = require('./statsNotifier');

module.exports = class Bots{

    static init(){
        //statsNotifier.init();
    }

}